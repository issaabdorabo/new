package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.CustomerEntity
import com.example.data.entity.InventoryEntity
import com.example.data.entity.OrderEntity
import com.example.data.entity.OrderItemEntity
import com.example.data.entity.PartEntity
import com.example.data.entity.PartyEntity
import com.example.data.entity.StockIssueEntity
import com.example.data.entity.SupplierOrderEntity
import com.example.data.entity.OrderPaymentEntity
import com.example.data.entity.SupplierReceiptEntity
import com.example.data.entity.TransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AutoPartsDao {

    // --- Parts ---
    @Query("SELECT * FROM parts ORDER BY id DESC")
    fun getAllParts(): Flow<List<PartEntity>>

    @Query("SELECT * FROM parts WHERE id = :id")
    suspend fun getPartById(id: Long): PartEntity?

    @Query("SELECT * FROM parts WHERE carType = :carType")
    suspend fun getPartsByCarType(carType: String): List<PartEntity>

    @Query("SELECT COUNT(*) FROM parts")
    suspend fun getPartsCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPart(part: PartEntity): Long

    @Update
    suspend fun updatePart(part: PartEntity)

    @Delete
    suspend fun deletePart(part: PartEntity)

    @Query("DELETE FROM parts WHERE id = :partId")
    suspend fun deletePartById(partId: Long)

    @Query("DELETE FROM parts WHERE carType = :carType")
    suspend fun deletePartsByCarType(carType: String)

    // --- Customers ---
    @Query("SELECT * FROM customers ORDER BY id ASC")
    fun getAllCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getCustomerById(id: Long): CustomerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: CustomerEntity): Long

    @Update
    suspend fun updateCustomer(customer: CustomerEntity)

    @Delete
    suspend fun deleteCustomer(customer: CustomerEntity)

    // --- Parties ---
    @Query("SELECT * FROM parties ORDER BY id ASC")
    fun getAllParties(): Flow<List<PartyEntity>>

    @Query("SELECT * FROM parties WHERE id = :id")
    suspend fun getPartyById(id: Long): PartyEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertParty(party: PartyEntity): Long

    @Update
    suspend fun updateParty(party: PartyEntity)

    @Delete
    suspend fun deleteParty(party: PartyEntity)

    // --- Inventory ---
    @Query("SELECT * FROM inventory")
    fun getAllInventory(): Flow<List<InventoryEntity>>

    @Query("SELECT * FROM inventory WHERE partId = :partId LIMIT 1")
    suspend fun getInventoryByPartId(partId: Long): InventoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventory(inventory: InventoryEntity): Long

    @Update
    suspend fun updateInventory(inventory: InventoryEntity)

    @Query("DELETE FROM inventory WHERE partId = :partId")
    suspend fun deleteInventoryByPartId(partId: Long)

    // --- Orders ---
    @Query("SELECT * FROM orders ORDER BY updatedAt DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE customerId = :customerId ORDER BY updatedAt DESC")
    fun getOrdersByCustomerId(customerId: Long): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE customerId = :customerId")
    suspend fun getOrdersListByCustomerId(customerId: Long): List<OrderEntity>

    @Query("SELECT * FROM orders WHERE id = :id")
    suspend fun getOrderById(id: Long): OrderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity): Long

    @Update
    suspend fun updateOrder(order: OrderEntity)

    @Delete
    suspend fun deleteOrder(order: OrderEntity)

    @Query("DELETE FROM orders WHERE customerId = :customerId")
    suspend fun deleteOrdersByCustomerId(customerId: Long)

    // --- Order Items ---
    @Query("SELECT * FROM order_items")
    fun getAllOrderItems(): Flow<List<OrderItemEntity>>

    @Query("SELECT * FROM order_items WHERE orderId = :orderId")
    fun getOrderItemsByOrderId(orderId: Long): Flow<List<OrderItemEntity>>

    @Query("SELECT * FROM order_items WHERE orderId = :orderId")
    suspend fun getOrderItemsByOrderIdDirect(orderId: Long): List<OrderItemEntity>

    @Query("SELECT * FROM order_items WHERE orderId = :orderId AND partId = :partId LIMIT 1")
    suspend fun getOrderItem(orderId: Long, partId: Long): OrderItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderItem(item: OrderItemEntity): Long

    @Update
    suspend fun updateOrderItem(item: OrderItemEntity)

    @Delete
    suspend fun deleteOrderItem(item: OrderItemEntity)

    @Query("DELETE FROM order_items WHERE orderId = :orderId")
    suspend fun deleteOrderItemsByOrderId(orderId: Long)

    @Query("DELETE FROM order_items WHERE orderId = :orderId AND partId = :partId")
    suspend fun deleteOrderItemByPart(orderId: Long, partId: Long)

    @Query("DELETE FROM order_items WHERE partId = :partId")
    suspend fun deleteOrderItemsByPartId(partId: Long)

    // --- Supplier Orders (Sorted newest first) ---
    @Query("SELECT * FROM supplier_orders ORDER BY orderDate DESC, id DESC")
    fun getAllSupplierOrders(): Flow<List<SupplierOrderEntity>>

    @Query("SELECT * FROM supplier_orders WHERE id = :id")
    suspend fun getSupplierOrderById(id: Long): SupplierOrderEntity?

    @Query("SELECT * FROM supplier_orders WHERE batchId = :batchId")
    suspend fun getSupplierOrdersByBatchId(batchId: String): List<SupplierOrderEntity>

    @Query("SELECT * FROM supplier_orders")
    suspend fun getAllSupplierOrdersDirect(): List<SupplierOrderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupplierOrder(supplierOrder: SupplierOrderEntity): Long

    @Update
    suspend fun updateSupplierOrder(supplierOrder: SupplierOrderEntity)

    @Delete
    suspend fun deleteSupplierOrder(supplierOrder: SupplierOrderEntity)

    @Query("DELETE FROM supplier_orders WHERE id = :id")
    suspend fun deleteSupplierOrderById(id: Long)

    // --- Stock Issues ---
    @Query("SELECT * FROM stock_issues ORDER BY createdAt DESC")
    fun getAllStockIssues(): Flow<List<StockIssueEntity>>

    @Query("SELECT * FROM stock_issues WHERE id = :id")
    suspend fun getStockIssueById(id: Long): StockIssueEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockIssue(stockIssue: StockIssueEntity): Long

    @Update
    suspend fun updateStockIssue(stockIssue: StockIssueEntity)

    @Delete
    suspend fun deleteStockIssue(stockIssue: StockIssueEntity)

    @Query("DELETE FROM stock_issues WHERE id = :id")
    suspend fun deleteStockIssueById(id: Long)

    // --- Transactions (Audit Log) ---
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(tx: TransactionEntity): Long

    // --- Order Payments ---
    @Query("SELECT * FROM order_payments ORDER BY paymentDate ASC, id ASC")
    fun getAllOrderPayments(): Flow<List<OrderPaymentEntity>>

    @Query("SELECT * FROM order_payments WHERE orderId = :orderId ORDER BY paymentDate ASC, id ASC")
    fun getPaymentsByOrderId(orderId: Long): Flow<List<OrderPaymentEntity>>

    @Query("SELECT * FROM order_payments WHERE orderId = :orderId ORDER BY paymentDate ASC, id ASC")
    suspend fun getPaymentsByOrderIdDirect(orderId: Long): List<OrderPaymentEntity>

    @Query("SELECT * FROM order_payments WHERE id = :id")
    suspend fun getPaymentById(id: Long): OrderPaymentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: OrderPaymentEntity): Long

    @Update
    suspend fun updatePayment(payment: OrderPaymentEntity)

    @Delete
    suspend fun deletePayment(payment: OrderPaymentEntity)

    @Query("DELETE FROM order_payments WHERE id = :id")
    suspend fun deletePaymentById(id: Long)

    @Query("DELETE FROM order_payments WHERE orderId = :orderId")
    suspend fun deletePaymentsByOrderId(orderId: Long)

    // --- Supplier Receipts ---
    @Query("SELECT * FROM supplier_receipts ORDER BY receiptDate ASC, id ASC")
    fun getAllSupplierReceipts(): Flow<List<SupplierReceiptEntity>>

    @Query("SELECT * FROM supplier_receipts WHERE supplierOrderId = :orderId ORDER BY receiptDate ASC, id ASC")
    fun getReceiptsBySupplierOrderId(orderId: Long): Flow<List<SupplierReceiptEntity>>

    @Query("SELECT * FROM supplier_receipts WHERE supplierOrderId = :orderId ORDER BY receiptDate ASC, id ASC")
    suspend fun getReceiptsBySupplierOrderIdDirect(orderId: Long): List<SupplierReceiptEntity>

    @Query("SELECT * FROM supplier_receipts WHERE id = :id")
    suspend fun getSupplierReceiptById(id: Long): SupplierReceiptEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupplierReceipt(receipt: SupplierReceiptEntity): Long

    @Update
    suspend fun updateSupplierReceipt(receipt: SupplierReceiptEntity)

    @Delete
    suspend fun deleteSupplierReceipt(receipt: SupplierReceiptEntity)

    @Query("DELETE FROM supplier_receipts WHERE id = :id")
    suspend fun deleteSupplierReceiptById(id: Long)

    @Query("DELETE FROM supplier_receipts WHERE supplierOrderId = :orderId")
    suspend fun deleteReceiptsBySupplierOrderId(orderId: Long)

    // --- Wipe Database for Clean Reset ---
    @Query("DELETE FROM parts")
    suspend fun clearParts()

    @Query("DELETE FROM customers")
    suspend fun clearCustomers()

    @Query("DELETE FROM parties")
    suspend fun clearParties()

    @Query("DELETE FROM inventory")
    suspend fun clearInventory()

    @Query("DELETE FROM orders")
    suspend fun clearOrders()

    @Query("DELETE FROM order_items")
    suspend fun clearOrderItems()

    @Query("DELETE FROM supplier_orders")
    suspend fun clearSupplierOrders()

    @Query("DELETE FROM stock_issues")
    suspend fun clearStockIssues()

    @Query("DELETE FROM transactions")
    suspend fun clearTransactions()

    @Query("DELETE FROM order_payments")
    suspend fun clearOrderPayments()

    @Query("DELETE FROM supplier_receipts")
    suspend fun clearSupplierReceipts()
}
